import sys
from PyQt5 import uic
from PyQt5.QtWidgets import QApplication, QMainWindow, QGroupBox, QPushButton, QMessageBox, QFileDialog
 
 
class MyWidget(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi('yoide.ui',self)
        self.current = None
        self.button_open.clicked.connect(self.showDialog)
        self.button_save_how.clicked.connect(self.user_save_button)
        self.button_save.clicked.connect(self.user_save_current_button)
 
    def showDialog(self):
        try:
            fname = QFileDialog.getOpenFileName(self, 'Open file', '/home')[0]
            self.program_text.setPlainText(open(fname, "r").read())
            self.current = fname
        except Exception:
            QMessageBox.about(self, "Ошибка", "Произошла ошибка при открытии файла!")

    def user_save_button(self):
        dir = QFileDialog.getSaveFileName()[0]
        self.abstract_save(dir)

    def user_save_current_button(self):
        self.abstract_save(self.current)

    def abstract_save(self, dir):
        try:
            with open(dir, "w") as f:
                f.write(self.program_text.toPlainText())
            self.current = dir
            QMessageBox.about(self, "Сохранение", "Файл успешно сохранен!")
        except Exception:
            QMessageBox.about(self, "Ошибка", "Произошла ошибка при сохранении файла!")
 
 
app = QApplication(sys.argv)
ex = MyWidget()
ex.show()
sys.exit(app.exec_())