var SITENAME = "http://127.0.0.1:5000/";


function getXmlHttp() {
    var xmlhttp;
    try {
        xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
    } catch (e) {
        try {
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        } catch (E) {
            xmlhttp = false;
        }
    }
    if (!xmlhttp && typeof XMLHttpRequest != 'undefined') {
        xmlhttp = new XMLHttpRequest();
    }
    return xmlhttp;
}

function query(handler, data, func, process_func, rettype = "text") {
    var xmlhttp = getXmlHttp();
    xmlhttp.open('POST', SITENAME + handler, true);
    xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    let params_str = "";
    for (let [key, value] of data.entries()) {
        params_str += key + "=" + encodeURIComponent(value) + "&"
    }
    xmlhttp.send(params_str.substr(0, params_str.length - 1));
    if (process_func) process_func();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState == 4) {
            if (xmlhttp.status == 200) {
                //alert(xmlhttp.responseText);
                func(xmlhttp);


            }
        }

    };
}

function run(code) {
    let output = document.querySelector("#output");
    load_img.style.display = "block";
    output.innerHTML = "";
    let data = new Map([
        ["code", code],
        ["lang", "ru"],
    ]);
    check_input();
    query('compile_and_run', data, after_run, in_process_run);


}

after_run = function (xmlhttp) {
    in_process_run();
    load_img.style.display = "none";
};

in_process_run = function () {
    let output = document.querySelector("#output");
    query("get_output", new Map([]), function (output_xmlhttp) {
        if (output_xmlhttp.responseText) output.innerHTML = output_xmlhttp.responseText;
    });
    query("is_running", new Map([]), function (is_run_xmlhttp) {
        // alert(is_run_xmlhttp.responseText);
        if (is_run_xmlhttp.responseText == "True") setTimeout(in_process_run, 10);
    });


};

check_input = function () {
    query("is_input", new Map([]), function (is_run_xmlhttp) {
        // alert(is_run_xmlhttp.responseText);
        if (is_run_xmlhttp.responseText == "True") {
            let input_data = prompt("Ввод данных:");
            let params = new Map([
                ["input_data", input_data],
            ]);
            query('push_input', params, function() {});
        }
    });
    query("is_running", new Map([]), function (is_run_xmlhttp) {
        if (is_run_xmlhttp.responseText == "True") setTimeout(check_input, 100);
    });
};