function createRange(node, chars, range) {
    if (!range) {
        range = document.createRange()
        range.selectNode(node);
        range.setStart(node, 0);
    }

    if (chars.count === 0) {
        range.setEnd(node, chars.count);
    } else if (node && chars.count > 0) {
        if (node.nodeType === Node.TEXT_NODE) {
            if (node.textContent.length < chars.count) {
                chars.count -= node.textContent.length;
            } else {
                range.setEnd(node, chars.count);
                chars.count = 0;
            }
        } else {
            for (var lp = 0; lp < node.childNodes.length; lp++) {
                range = createRange(node.childNodes[lp], chars, range);

                if (chars.count === 0) {
                    break;
                }
            }
        }
    }

    return range;
}

function setCurrentCursorPosition(chars) {
    if (chars >= 0) {
        var selection = window.getSelection();

        range = createRange(document.getElementById("code"), {count: chars + 1});
        //alert(chars);
        if (range) {
            range.collapse(false);
            selection.removeAllRanges();
            selection.addRange(range);
        }
    }
}


function isChildOf(node, parentId) {
    while (node !== null) {
        if (node.id === parentId) {
            return true;
        }
        node = node.parentNode;
    }

    return false;
}

function getCurrentCursorPosition(parentId) {
    var selection = window.getSelection(),
        charCount = -1,
        node;

    if (selection.focusNode) {
        if (isChildOf(selection.focusNode, parentId)) {
            node = selection.focusNode;
            charCount = selection.focusOffset;

            while (node) {
                if (node.id === parentId) {
                    break;
                }

                if (node.previousSibling) {
                    node = node.previousSibling;
                    charCount += node.textContent.length;
                } else {
                    node = node.parentNode;
                    if (node === null) {
                        break
                    }
                }
            }
        }
    }

    return charCount;
}


function clearFromTags(text) {
    var tags = ["obj", "com", "str", "func", "div", "struct", "logic"];
    for (var i = 0; i < tags.length; i++) {

        text = text.replace(new RegExp('<' + tags[i] + '>', 'g'), '');
        text = text.replace(new RegExp('</' + tags[i] + '>', 'g'), '');
    }
    return text; //.replace(/<[^>]+>/g,'');

}

// .replace(/<[^>]+>/g,'');

var code = document.querySelector("#code");
var codeshow = document.querySelector("#codeshow");
var play = document.querySelector(".play_button");
var old_variant = clearFromTags(code.innerHTML);
var pos = undefined;
let load_img = document.querySelector("#load_img");


$(".play_button")[1].addEventListener('click', function() {
    let code_text = code.innerText.replace(new RegExp('\xa0', 'g'), '');
    run(code_text);
});



$('div[contenteditable=true]').keydown(function (e) {
    // trap the return key being pressed
    if (e.keyCode == 8) {
        codeshow.innerHTML = code.innerHTML;
    }
    else if (e.keyCode == 9) {
        // We press TAB
        document.execCommand('insertHTML', false, '<pre>    </pre>');
        // prevent the default behaviour of return key pressed
        codeshow.innerHTML = code.innerHTML;
        return false;
    }
    else if (e.keyCode == 13) {
        // insert 2 br tags (if only one br tag is inserted the cursor won't go to the second line)
        document.execCommand('insertHTML', false, '<br><br>');
        // prevent the default behaviour of return key pressed
        codeshow.innerHTML = code.innerHTML;
        return false;
    }
});
code.addEventListener("DOMCharacterDataModified", function (el) {


    var current_text = code.innerHTML;
    current_text = clearFromTags(current_text);
    //if (current_text == old_variant) return;

    pos = getCurrentCursorPosition('code');
    //console.log(pos);
    current_text = current_text
    // ключевые слова (список неполон, написал, что в голову пришло)
        .replace(/(if|for|in|while|break|continue|else|elseif)([^a-z0-9\$_])/gi,
            '<struct>$1</struct>$2')
        .replace(/(true|false)([^a-z0-9\$_])/gi,
        '<logic>$1</logic>$2')
        // всякие скобочки
        .replace(/(\{|\}|\]|\[|\|)/gi, '<obj>$1</obj>')
        // однострочные комментарии
        .replace(/(\/\/[^\n\r]*(\n|\r\n))/g, '<com>$1</com>')
        // строки
        .replace(/('.*?')/g, '<str>$1</str>')
        // функции (когда после идентификатора идет скобка)
        .replace(/([a-z\_\$][a-z0-9_]*)\(/gi, '<func>$1</func>(');
    codeshow.innerHTML = current_text;

    setCurrentCursorPosition(pos);
    //old_variant = current_text;


});

code.addEventListener('scroll', function() {
  codeshow.scroll(0, code.scrollTop);

});


$('div[contenteditable=true]').focusout(function(eventObject){
  console.log('Элемент foo потерял фокус.');
  code.focus();
  setCurrentCursorPosition(pos);
});



