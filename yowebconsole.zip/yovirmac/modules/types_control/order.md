В модулях write.py, read.py и display.py методы называются одинаково,
Они должны идти в следующем порядке:

1. bit
2. cell (также clean в write)
3. kind
4. none
5. link
6. command
7. logic
8. number
9. char
10. string

Новые функции нужно внедрять от модуля к модулю в порядке write - 
read - display