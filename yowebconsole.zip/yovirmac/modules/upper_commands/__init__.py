__all__ = ["comparison", "console", "jumps", "logic", "math", "objects",
           "other", "stack"]
