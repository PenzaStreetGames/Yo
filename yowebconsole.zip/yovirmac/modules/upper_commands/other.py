def No_operation():
    pass
