from flask import Flask, render_template, request, session
from yotranslator import yo_translator as translator
import yovirmac.yo_vir_mac as virtual_machine
import yovirmac.modules.constants as constants
from yovirmac.modules.tape_control.add import decode_assembly

import traceback

app = Flask(__name__)
app.config['SECRET_KEY'] = 'dryandex_corp'


@app.route('/')
def hello_world():
    return render_template("index.html", name=1)


@app.route('/compile_and_run', methods=['GET', 'POST'])
def compile_and_run():
    constants.webmode = True
    try:
        session["is_running"] = True
        with open("static/res_output.txt", "w", encoding="utf8") as upd_file:
            upd_file.seek(0)
            upd_file.write("")

        try:
            code = request.form["code"]
            lang = request.form["lang"]
            result = translator.compile_program(code, language=lang, mode="web")

        except Exception as error:
            trace = traceback.format_exception(error.__class__, error,
                                               error.__traceback__)
            return "Ошибка компиляции: \n"

        target_cell = virtual_machine.execute_program(decode_assembly(result))
        while target_cell != 0:

            try:
                target_cell = virtual_machine.next_command(target_cell)
            except Exception as error:

                trace = traceback.format_exception(error.__class__, error,
                                                   error.__traceback__)
                return "Ошибка исполнения:" + "".join(trace)
            if constants.input_data:
                # print(constants.input_data)
                constants.input_data = []
            if constants.output_data:
                # print(constants.output_data)
                with open("static/res_output.txt", "a", encoding="utf8") as file_output:
                    file_output.write(constants.output_data[0] + "\n")
                constants.output_data = []

        print("OK!", target_cell)
        with open("static/res_output.txt", "r", encoding="utf8") as file:
            print("file1>>", len(file.readlines()))
        session["is_running"] = False

        return "OK"
    except Exception:
        print("!!! SOMETHING WAS WRONG FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF")


@app.route('/get_output', methods=["POST"])
def get_output():
    with open("static/res_output.txt", "r") as file:
        data = file.read().replace("\n", "<br>")
    return str(data)


@app.route('/is_running', methods=["POST"])
def is_running():
    return "True" if session["is_running"] else ""


@app.route('/is_input', methods=["POST"])
def is_input():
    return "True" if constants.is_input_web else ""


@app.route('/push_input', methods=["POST"])
def push_input():
    constants.input_data_web = request.form["input_data"]
    return "True"


if __name__ == '__main__':
    app.run()
